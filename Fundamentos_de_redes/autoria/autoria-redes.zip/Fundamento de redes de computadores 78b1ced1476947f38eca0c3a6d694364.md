# Fundamento de redes de computadores

[Camadas de redes](https://www.notion.so/Camadas-de-redes-50ca5f6d262f444b9bb3253255237c47)

- **Rede de computadores**
    
    Qualquer dois dispositivos conectados entre si
    

- As conexões entre os computadores da rede é chamada de enlace
- O computador principal é host
- enlace é um meio físico para passar a informação de um computador para outro dispositivo, ele pode ser:
    1. cabeado
        1. fibra óptica
        2. ethernet
        3. coaxial
    2. sem fio
    3. cabeado

<aside>
⚙ O cabo ethernet ele trança os cabos em pares para anular seus eletromagnetismos, ficando 8 fios, ele perde a informação a distancia

</aside>

<aside>
⚙ O cabo coaxial funciona com uma gaiola de faraday para barrar os campos eletromagnético

</aside>

<aside>
⚙ O cabo de fibra óptica usa fios de vidros ultra finos para passar a energia, sendo bom para as longas distancias e

</aside>

### Dispositivos

- O switch conecta vários computadores
    - Com o tempo ele aprende com a tabela de comutação
    
    <aside>
    💡 A tabela de comutação é a tabela que armazena as posições dos computadores do switch, o switch aprende a posição só de quem mandou o
    
    </aside>
    
- O patch panel conecta um ponto a outro
- hub ele conecta vários pontos entre si
    - ele não tem controle, ele envia o pacote para todos os diapositivos que estiverem nele e os que não requisitaram descartam o pacote

### Etapas da rede

O dispositivo é conectado em uma tomada de telecom que leva até um patch panel conectado no switch da rede

### Tabela de tipos de redes

| sigla | definição | objetivo |
| --- | --- | --- |
| LAN | Local Area Network | Conexão de até 250 dispositivos |
| MAN | Metripolitan Area Network | Conectar dispositivos em uma área de uma cidade |
| RAN | Regional Area Network | Conectar dispositivos em uma área maior que uma cidade |
| WAN | Worldwide Area Network | Conectar o mundo inteiro |
| VPN | Virtual Private Network | Conseguir acessar todos os dados sem estar no ambiente físico |

### Rede LAN

- Rede pequena
- Normalmente de cabos ethernet
- Empresa/Casa
- Administrador tem acesso a toda rede
- Todos os dispositivos possuem a mesma mascara
    - Mascara é a parte do IP que identifica a rede
- Todos os dispositivos com o mesmo endereço de rede

Equipamentos usados:

- celular
- computador
- impressoras
- Tv
- telefone
- switch
- patch panel
- modem
- roteador

### Rede WAN

- Rede muito maior
- Ninguém tem controle de toda a rede
- todos os dispositivos estão conectados fisicamente
- Não sei todos os IPs
- Não tem um padrão nos IPs

## História das Redes

No inicio começou com os telefones, sendo conectados entre si por cabos, mas com o grande aumento de usuários todas as conexões foram feitas numa central, onde o telefonista conectava manualmente. Até que uma pessoa fez um sistema que não precisasse passar pela telefonista, chamada atualmente de comutação.

> Comutação de circuitos você aluga o caminho inteiro só para você
> 

> Comutação de Pacotes você aluga a pista quando você for usar, podendo ter fila
> 

### Medidas

- Tamanho do da informação
    
    L - length (bit - b)
    
- Taxa de transmissão
    
    R - ratio (bps)
    
- Tempo
    
    T - tempo (s)
    

### Conexão do Computador até o Servidor

![Untitled](Fundamento%20de%20redes%20de%20computadores%2078b1ced1476947f38eca0c3a6d694364/Untitled.png)

- Borda da rede, exemplo, o computador e o servidor.
- Núcleo da rede, exemplo, a nuvem.

## Protocolos

Língua da computação

| 1 | 2 |
| --- | --- |
| pacote | ack |
| google.com | (arquivo) |
| fim | ack |

| 1 | 2 |
| --- | --- |
| oi | entendido |
| pergunta | responde |
| tchau | entendido |

## TCP - Transmission Control Protocol

- Preza pela integridade dos pacotes
    - Tem que chegar
    - Tem que chegar na ordem - numera os pacotes
    - Tem que chegar sem erro- códigos corretores de erro
- Sem perda de qualidade
- Mais tempo
    - email
    - envia foto no discord

## UDP - User Datagram Protocol

- Não importa se chega, se não chega na ordem ou se chega com erro
- não tem nenhum controle
- é muito mais rápido
    - meet
    - skype
    - discord

### Modelos

Modelo cliente servidor

![Design sem nome (1).png](Fundamento%20de%20redes%20de%20computadores%2078b1ced1476947f38eca0c3a6d694364/Design_sem_nome_(1).png)

Modelo Peer-to-Peer

![Design sem nome (2).png](Fundamento%20de%20redes%20de%20computadores%2078b1ced1476947f38eca0c3a6d694364/Design_sem_nome_(2).png)

## Redes

A rede usa IP para identificar os computadores, sendo separado em 4 octetos de binário, sendo o mínimo 0 e o máximo 255

- endereço de rede identifica o inicio da rede
- endereço de dispositivo identifica o computador na rede
- mascara determina a quantidade maxima de dispositivos
- endereço de broadcast identifica o fim da rede
- endereço de gateway é o endereço dedicado ao roteador

Esse 29 determina a quantidade de dispositivos e também a parte do IP que pertence a rede. Ficaria assim 11111111.11111111.11111111.11111000, ou seja os 1 são parte da rede e os 0 são parte do dispositivo, ficaria:

- Endereço de rede: 192.0.34.192
- Numero do dispositivo: 0.0.0.3

Para descobrir a quantidade de dispositivos precisamos elevar dois à 32 subtraído pela mascara subtraído por 2, ficaria:

2^(32-29)-2

Ou seja teríamos no máximo 6 dispositivos.

Para descobrir o broadcast precisa pega os 0 da mascara e transforma em um, ficaria:

- Endereço de broadcast: 192.0.34.199

O endereço mínimo e máximo são definidos pelo endereço de rede e de broadcast respectivamente.