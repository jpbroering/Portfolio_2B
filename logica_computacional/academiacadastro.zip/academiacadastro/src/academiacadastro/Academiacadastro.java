package academiacadastro;
import static java.awt.image.ImageObserver.WIDTH;
import java.util.ArrayList;
import java.util.Random;
import javax.swing.JOptionPane;

public class Academiacadastro {
    ArrayList<Cadastrado> lista = new ArrayList<>();
    public static void main(String[] args) {
        Academiacadastro academia = new Academiacadastro();
        academia.opcoes();
    }
    public long geraid(){
        Random gerador = new Random();
        int imin = 10000;
        long id = gerador.nextInt(90000)+imin;
        return(id);
    }
    public void opcoes(){
        String[] opcoes = {"cadastrar","remover","listar","editar"};
        int opcao = JOptionPane.showOptionDialog(null, "O que deseja editar?","Opções" ,WIDTH, WIDTH, null, opcoes, opcoes[0]);
        switch(opcao){
            case 0:
                cadastra(lista);
                break;
            case 1:
                remove(lista);
                break;
            case 2:
                list(lista);
                break;
            case 3:
                edit(lista);
                break;
            default:
                return;
        }
        opcoes();
    }
    public void cadastra(ArrayList<Cadastrado> lista){
        String nome = JOptionPane.showInputDialog("Digite o nome");
        int idade = Integer.parseInt(JOptionPane.showInputDialog("Digite o idade"));
        String cpf = JOptionPane.showInputDialog("Digite o CPF");
        String id = String.valueOf(geraid());
        Cadastrado a = new Cadastrado(nome, idade, cpf, id);
        lista.add(a);
    }
    public void remove(ArrayList<Cadastrado> lista){
        String mat = JOptionPane.showInputDialog(null,"Digite o Casdastro do aluno que deseja EDITAR");
        String mensagem = "Cadastro não encontrada!";
        for(Cadastrado a : lista){
            //JOptionPane.showMessageDialog(null,"ID encontrado é "+a.getId());
            if(mat.equals(a.getId())){
                mensagem = a.getNome()+" deletado com sucesso!";
                String[] opcoes = {"Deletar","Não deletar"};
                int opcao = JOptionPane.showOptionDialog(null, "Deseja realmete deletar?", a.getNome(), WIDTH, WIDTH, null, opcoes, opcoes[0]);
                switch(opcao){
                    case 0:
                       lista.remove(a);
                       break;
                    case 1:
                        mensagem = "Operação cancelada!";
                        break;
                }
                break;
            }
        }
        JOptionPane.showMessageDialog(null,mensagem);
    }
    public void list(ArrayList<Cadastrado> lista){
        String Cadastrados = "Cadastrados";
        for (Cadastrado a : lista) {
            Cadastrados = Cadastrados+"\n_________\nNome: " + a.getNome() + "\nIdade: " + a.getIdade() + "\nCPF: " + a.getCpf() + "\nId: " + a.getId();
        }
        JOptionPane.showMessageDialog(null,Cadastrados);
    }
    public void edit(ArrayList<Cadastrado> lista){
        String mat = JOptionPane.showInputDialog(null,"Digite a matrícula do aluno que deseja EDITAR");
        String mensagem = "Id não encontrada!";
        for(Cadastrado a : lista){
            if(mat.equals(a.getId())){
                mensagem = a.getNome()+" editado com sucesso!";
                String[] opcoes = {"Nome","Idade","CPF","Id"};
                int opcao = JOptionPane.showOptionDialog(null, "O que deseja editar?", a.getNome(), WIDTH, WIDTH, null, opcoes, opcoes[0]);
                switch(opcao){
                    case 0:
                       a.setNome(JOptionPane.showInputDialog(null,"Digite o novo nome!"));
                       break;
                    case 1:
                        try{
                           a.setIdade(Integer.parseInt(JOptionPane.showInputDialog(null,"Digite a nova idade!"))); 
                        }catch(Exception e){
                            mensagem = "Valor inválido!";
                        }                        
                        break;
                    case 2:
                        a.setCpf(JOptionPane.showInputDialog(null,"Digite o novo CPF!"));
                        break;
                    case 3:
                        a.setId(JOptionPane.showInputDialog(null,"Digite a nova matrícula!"));
                }
            }
        }
        JOptionPane.showMessageDialog(null,mensagem);
    }
}
