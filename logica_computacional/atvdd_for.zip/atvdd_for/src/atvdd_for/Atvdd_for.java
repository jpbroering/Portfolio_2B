/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package atvdd_for;

import java.util.ArrayList;
import javax.swing.JOptionPane;

/**
 *
 * @author joao_broering
 */
public class Atvdd_for {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        int n = Integer.parseInt(JOptionPane.showInputDialog("Escolha um numero"));
        primos(n);
        
//        ArrayList<String> lista = new ArrayList<>();
//        for(int t = n; t>0; t--){
//            primos(n);
//        }
        
    }
    public static void primos(int n){
        for(int i = 0; i < n; i++){
            int d = 0;
            for(int j = i;j>0;j--){
                if(i%j==0){
                    d++;
                }
            
        }
         if(d==2){
                print(i+"\n");
            }   
    }
}
    public static void print(String msg){
        System.out.println(msg);
    }
}
